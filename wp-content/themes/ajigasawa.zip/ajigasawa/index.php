<?php get_header(); ?>
<!-- メイン -->
<main>
	<div class="container">
		<img src="<?php bloginfo('template_url'); ?>/img/hero.svg" alt="あじがさわ応援めしプロジェクト">
		<img src="<?php bloginfo('template_url'); ?>/img/hero_sub.svg" alt="得々応援めしチケットをゲットしてお得にお食事を楽しもう！">
	</div>
</main>
<?php get_footer(); ?>