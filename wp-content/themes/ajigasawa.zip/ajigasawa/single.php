<?php get_header()?>
    <!-- メイン -->
    <main>
        <div class="container">
            <div style="height:100vh;">test</div>
        </div>
    </main>
<?php get_footer()?>