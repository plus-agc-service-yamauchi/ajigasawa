<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <title><?php wp_title('|', true, 'right');?><?php bloginfo('name');?></title>
    <!-- Reset -->
    <link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/reset.css">
    <!-- Grid -->
    <link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/grid.css">
    <!-- Original Style -->
    <link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/default.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Sawarabi+Gothic&display=swap" rel="stylesheet">
    <!-- Original CSS default.cssへ統合 -->
    <style>
        header{
            margin
        }
    </style>
    <?php wp_head();?>
</head>

<body>
    <!-- ヘッダー -->
    <header>

    </header>